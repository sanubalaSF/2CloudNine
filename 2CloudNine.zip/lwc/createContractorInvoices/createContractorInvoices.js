import { LightningElement,track,wire } from 'lwc';
import getAccounts from '@salesforce/apex/CreateContractorInvoicesController.getAccounts';
import batchExecution from '@salesforce/apex/CreateContractorInvoicesController.batchExecution';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class CreateContractorInvoices extends LightningElement {
    accounts;
    accountValue = '';
    @track startDate;
    @track endDate;
    @track isLoading = true;

    connectedCallback(){
        var today = new Date();
        this.startDate=today.toISOString();
        this.startDate=this.startDate.slice(0,10);
        this.endDate=today.toISOString();
        this.endDate=this.endDate.slice(0,10);
    }

    @wire(getAccounts)
    wiredgetAccounts(value) {        
        if (value.error) {
            this.error = value.error;
        } else if (value.data) {
            console.log(value.data);
            let accounts=[];
            accounts.push({ label: 'All', value:'' });
            for(let i=0;i<value.data.length;i++){
                accounts.push({ label: value.data[i].Name, value: value.data[i].Id });
            }
            console.log(accounts);
            this.accounts = accounts;
            this.isLoading = false;
        }
    }
    /** Handles event to change */
    handleStartDateChange(event) {
        this.startDate=event.target.value;
        this.validatationForDate();
    }
    handleEndDateChange(event) {
        this.endDate=event.target.value;
        this.validatationForDate();
    }
    validatationForDate(){
        let StartDateInput=this.template.querySelector(".StartDate");
        console.log(StartDateInput);
        let EndtDate=this.template.querySelector(".EndDate");
        console.log(this.startDate.slice(0,10),'-----',this.endDate.slice(0,10));
        let StartDate=new Date(this.startDate.slice(0,10));
        let EndDate=new Date(this.endDate.slice(0,10));
        console.log(StartDate,'-----',EndDate);
        if( StartDate > EndDate){
             //set an error
             StartDateInput.setCustomValidity("Start Date must be less then End Date.");
             StartDateInput.reportValidity();
        }else{
            //set an error
            StartDateInput.setCustomValidity("");
            StartDateInput.reportValidity();
        }
    }
    handleChange(event){
        this.accountValue=event.target.value;
    }
    handleBatchExecution(event){
        if(this.startDate && this.endDate){
            this.isLoading = true;
            let accIds=[];
            console.log(this.accountValue);
            for(let i=0;i<this.accounts.length;i++){
                if(this.accountValue == ""){
                    if(this.accounts[i].value !== ''){
                        //console.log(this.accounts[i].value);
                        accIds.push(this.accounts[i].value);
                    }
                }else{
                    accIds.push(this.accountValue);
                    break;
                }                
            }
            console.log(accIds);
            batchExecution({accIds: accIds,startDate : this.startDate.slice(0,10),endDate:this.endDate.slice(0,10)})
            .then(results => {
                // eslint-disable-next-line no-console
                console.log('Batch Execution :'+JSON.stringify(results)); 
                let variant= results == 'No Record found' ? 'info' : 'success';
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Success',
                    message: results,
                    variant: variant,
                })); 
                this.isLoading = false;          
            })
            .catch(error => {
                // eslint-disable-next-line no-console
                console.error('Lookup error', JSON.stringify(error));
                this.isLoading = false;
            });
        }
        
    }
}